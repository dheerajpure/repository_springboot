package dp.test.springboot.security.with_h2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import dp.test.springboot.security.with_h2.model.Users;
import dp.test.springboot.security.with_h2.repository.UsersRepository;

@RequestMapping("/db")
@RestController
public class DbController {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
    @Autowired
    private UsersRepository usersRepository;
    
    @RequestMapping(value="/getAllUsers",method = RequestMethod.GET)
    public List<Users> getAllUsers() {
    	return usersRepository.findAll();
    }
	
	@RequestMapping(value="/createRoleTable",method = RequestMethod.GET)
	public void createRoleTable() {
		String sql1="DROP TABLE IF EXISTS `role`;";
		
		String sql2="DROP TABLE IF EXISTS `role`;";
		
		String sql3="CREATE TABLE `role` (\r\n" + 
				"\r\n" + 
				"  `role_id` int(11) NOT NULL AUTO_INCREMENT,\r\n" + 
				"\r\n" + 
				"  `role` varchar(255) DEFAULT NULL,\r\n" + 
				"\r\n" + 
				"  PRIMARY KEY (`role_id`)\r\n" + 
				"\r\n" + 
				") ";
		jdbcTemplate.execute(sql1);
		jdbcTemplate.execute(sql2);
		jdbcTemplate.execute(sql3);
	}
	
	@RequestMapping(value="/createUserTable",method = RequestMethod.GET)
	public void createUserTable() {
		String sql1="DROP TABLE IF EXISTS `user`;";
		
		String sql2="CREATE TABLE `user` (\r\n" + 
				"\r\n" + 
				"  `user_id` int(11) NOT NULL AUTO_INCREMENT,\r\n" + 
				"\r\n" + 
				"  `active` int(11) DEFAULT NULL,\r\n" + 
				"\r\n" + 
				"  `email` varchar(255) NOT NULL,\r\n" + 
				"\r\n" + 
				"  `last_name` varchar(255) NOT NULL,\r\n" + 
				"\r\n" + 
				"  `name` varchar(255) NOT NULL,\r\n" + 
				"\r\n" + 
				"  `password` varchar(255) NOT NULL,\r\n" + 
				"\r\n" + 
				"  PRIMARY KEY (`user_id`)\r\n" + 
				"\r\n" + 
				") ";
		String sql3="INSERT INTO `user` (`user_id`, `active`, `email`, `last_name`, `name`, `password`)\r\n" + 
				"\r\n" + 
				"VALUES\r\n" + 
				"\r\n" + 
				"	(1,1,'admin@gmail.com','s','Sam','sam'),\r\n" + 
				"\r\n" + 
				"	(2,1,'admin@gmail.com','s','youtube','youtube');\r\n" + 
				"\r\n" + 
				"";
		
		jdbcTemplate.execute(sql1);
		jdbcTemplate.execute(sql2);
		jdbcTemplate.execute(sql3);
	}
	
}
