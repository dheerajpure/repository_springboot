package dp.test.springboot.security.with_h2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/*video
https://www.youtube.com/watch?v=egXtoL5Kg08
https://github.com/TechPrimers/spring-security-db-example


https://www.youtube.com/watch?v=BvynlTYhwsk
*/

@SpringBootApplication
public class SecurityWithH2Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityWithH2Application.class, args);
	}

}
